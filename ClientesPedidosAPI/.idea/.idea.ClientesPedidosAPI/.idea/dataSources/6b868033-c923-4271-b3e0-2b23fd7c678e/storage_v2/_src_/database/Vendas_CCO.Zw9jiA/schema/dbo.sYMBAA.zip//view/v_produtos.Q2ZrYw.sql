create view v_produtos
as
select prd_descricao Produto,
        prd_qtd       Estoque,
		prd_valor     Preco
from produtos
go

