create procedure cadConsumacao_Pipoca
(
	@pipoca_id int,
	@consumacao_id int,
	@qtd int
)
as
begin
	insert into Consumacao_Pipoca values (@pipoca_id, @consumacao_id, @qtd)
end
go

