create view ped_detalhes
as
	select pt.Pedido       Pedido,
		   pin.Data        Data,
		   pt.Valor_Item   Total,	   
		   pin.Cliente     Cliente,
		   pin.Funcionario Funcionario,
		   pin.Estagiario  Estagiario,
		   pin.Situação    Situação
	from ped_total pt, ped_info pin
	where pt.Pedido = pin.Pedido
go

