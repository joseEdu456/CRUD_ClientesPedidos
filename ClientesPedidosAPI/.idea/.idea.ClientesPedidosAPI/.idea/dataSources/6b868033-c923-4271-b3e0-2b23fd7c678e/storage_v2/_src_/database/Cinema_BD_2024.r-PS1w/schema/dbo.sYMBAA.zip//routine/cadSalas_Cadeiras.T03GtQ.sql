create procedure cadSalas_Cadeiras
(
	@sala_nr int,
	@cadeira_nr int
)
as
begin
	insert into Salas_Cadeiras values (@sala_nr, @cadeira_nr)
end
go

