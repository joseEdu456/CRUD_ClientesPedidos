
-------------------------------------------------------------
-- Procedure para cadastrar os Clientes na TABELA CLIENTES 
-------------------------------------------------------------
create procedure sp_CadCliente
(
	@nomeCli	varchar(50),		@fotoCli	varchar(50),
	@emailCli	varchar(100),		@senhaCli	varchar(20),
	@sts		int
)
as
begin
	insert into Clientes (nomeCli, foto, email, senha, status)
	values(@nomeCli, @fotoCli, @emailCli, @senhaCli, @sts)
end
go

