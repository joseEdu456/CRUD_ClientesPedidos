create procedure cadBebida
(
	@bebida_nome varchar(50),
	@bebida_tamanho varchar(15),
	@fabricante_id int
)
as
begin
	insert into Bebida values (@bebida_nome, @bebida_tamanho, @fabricante_id)
end
go

