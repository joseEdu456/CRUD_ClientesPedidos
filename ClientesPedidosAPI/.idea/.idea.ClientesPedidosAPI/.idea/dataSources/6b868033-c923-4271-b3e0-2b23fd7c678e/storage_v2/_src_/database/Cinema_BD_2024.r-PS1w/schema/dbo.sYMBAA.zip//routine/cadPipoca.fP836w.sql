create procedure cadPipoca
(
	@pipoca_valor decimal(10,2),
	@pipoca_tamanho varchar(15),
	@tipo_id int
)
as
begin
	insert into Pipoca values (@pipoca_valor, @pipoca_tamanho, @tipo_id)
end
go

