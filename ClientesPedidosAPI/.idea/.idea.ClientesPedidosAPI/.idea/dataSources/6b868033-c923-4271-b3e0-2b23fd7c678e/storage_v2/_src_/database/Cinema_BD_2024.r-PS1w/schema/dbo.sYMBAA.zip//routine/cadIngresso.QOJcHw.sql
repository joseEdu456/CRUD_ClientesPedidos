create procedure cadIngresso
(
	@ingresso_qtd int,
	@ingresso_valor decimal(10,2),
	@filme_id int,
	@sala_nr int,
	@sessao_nr int
)
as
begin
	insert into Ingressos values (@ingresso_qtd, @ingresso_valor, @filme_id, @sala_nr, @sessao_nr)
end
go

