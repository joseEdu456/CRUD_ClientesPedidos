create procedure cadTipo
(
	@tipo_nome varchar(20)
)
as
begin
	insert into Tipo values (@tipo_nome)
end
go

