CREATE trigger tr_01
on produtos
after update
as if update(prd_valor)
begin
    insert into logprecos
    select i.prd_codigo, getDate(),
	       d.prd_valor, i.prd_valor,
		   SYSTEM_USER        
	from deleted d, inserted i
	where i.prd_codigo = d.prd_codigo and
	      i.prd_valor != d.prd_valor	
end
go

