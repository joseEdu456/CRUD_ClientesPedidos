
-------------------------------------------------------------
-- Procedure para alteraros dados de um Produtos na 
-- TABELA PRODUTOS 
-------------------------------------------------------------
create procedure sp_UpProduto
(
	@idProd	int,				@nomeProd	varchar(20),	
	@descProd	varchar(100),	@qtdProd	int,			
	@precoProd	decimal(6,2),	@imgProd	varchar(150),	
	@stsProd	int,			@catIdProd	int
)
as
begin
	update Produtos set nome = @nomeProd, descricao = @descProd, 
						qtdProd = @qtdProd, valor = (@precoProd/100), 
						urlImg = @imgProd, status = @stsProd, 
						categoriaId = @catIdProd
	where idProduto = @idProd
end 
go

