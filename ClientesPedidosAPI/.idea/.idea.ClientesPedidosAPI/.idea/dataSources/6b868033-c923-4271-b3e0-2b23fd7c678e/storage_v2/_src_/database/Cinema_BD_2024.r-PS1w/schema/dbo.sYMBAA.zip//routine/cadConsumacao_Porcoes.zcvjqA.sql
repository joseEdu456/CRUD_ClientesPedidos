create procedure cadConsumacao_Porcoes
(
	@porcoes_id int,
	@consumacao_id int,
	@qtd int
)
as
begin
	insert into Consumacao_Porcoes values (@porcoes_id, @consumacao_id, @qtd)
end
go

