create view v_prods
as
select p.prd_codigo    Codigo,
       p.prd_descricao Produto,
	   p.prd_qtd       Estoque,
	   p.prd_valor     Preço,
	   case prd_status
	      when 1 then 'Ativo'
		  else 'Inativo'
	   end Situação,
	   case 
		 when prd_qtd <= 5 then 'Estoque Baixo'
		 else 'Normal'
	   end Situação_Estoque
from produtos p
go

