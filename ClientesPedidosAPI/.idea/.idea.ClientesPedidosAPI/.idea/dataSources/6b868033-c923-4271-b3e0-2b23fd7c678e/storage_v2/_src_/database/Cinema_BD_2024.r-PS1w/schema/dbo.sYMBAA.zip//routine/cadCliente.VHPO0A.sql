create procedure cadCliente
(
	@pessoa_id int,
	@estrelas   int
)
as
begin
	insert into Clientes values	(@pessoa_id,@estrelas)
end
go

