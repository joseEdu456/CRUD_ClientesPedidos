create procedure cadFuncionario
(
	@pessoa_id int,
	@salario   decimal(10,2)
)
as
begin
	insert into Funcionarios values	(@pessoa_id,@salario)
end
go

