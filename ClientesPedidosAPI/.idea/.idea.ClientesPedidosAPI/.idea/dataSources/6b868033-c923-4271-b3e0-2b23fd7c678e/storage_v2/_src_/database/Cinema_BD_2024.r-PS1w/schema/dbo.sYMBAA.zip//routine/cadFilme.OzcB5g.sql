create procedure cadFilme
(
	@filme_nome varchar(50)
)
as
begin
	insert into Filmes values	(@filme_nome)
end
go

