create procedure cadSessoes
(
	@horario datetime
)
as
begin
	insert into Sessoes (horario) values (@horario)
end
go

