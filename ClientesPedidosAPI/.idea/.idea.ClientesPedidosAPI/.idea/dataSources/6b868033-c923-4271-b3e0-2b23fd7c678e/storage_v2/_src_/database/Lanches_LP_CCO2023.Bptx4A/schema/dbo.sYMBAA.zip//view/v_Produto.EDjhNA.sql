
-------------------------------------------------------------
-- View para consultar todos os Produtos na TABELA PRODUTOS 
-------------------------------------------------------------
create view v_Produto
as
	select P.idProduto, P.nome NomeProd, P.descricao Descricao, 
	P.qtdProd QtdProd, P.valor Valor, P.urlImg UrlImg, P.status Status,
	P.categoriaId IdCategoria, C.categoria Categoria
	from Categorias C, Produtos P
	where P.categoriaId = C.idCategoria
go

