create procedure cadFormaPagamento
(
	@descricao varchar(50)
)
as
begin
	insert into FormaPagamento values (@descricao)
end
go

