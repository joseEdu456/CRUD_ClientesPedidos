create procedure cadFabricante
(
	@fabricante_nome varchar(30)
)
as
begin
	insert into Fabricante values (@fabricante_nome)
end
go

