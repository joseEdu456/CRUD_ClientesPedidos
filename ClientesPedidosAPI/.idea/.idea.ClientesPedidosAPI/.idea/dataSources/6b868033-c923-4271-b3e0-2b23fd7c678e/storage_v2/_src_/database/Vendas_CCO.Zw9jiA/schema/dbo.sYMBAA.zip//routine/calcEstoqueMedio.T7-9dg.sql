--------------------------------------------

create function calcEstoqueMedio (@produto int)
returns int
as
begin
   return 
   (
       select avg(itp_qtd) 
	   from itens_pedidos
       where prd_codigo = @produto
   )
end
go

