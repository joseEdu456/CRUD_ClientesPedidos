
-------------------------------------------------------------
-- Procedure para alteraros dados de um Cliente na 
-- TABELA CLIENTES 
-------------------------------------------------------------
create procedure sp_UpCliente
(
	@idCli		int,			@nomeCli	varchar(50),	
	@fotoCli	varchar(50),	@emailCli	varchar(100),	
	@senhaCli	varchar(20),	@sts		int
)
as
begin
	update Clientes set nomeCli = @nomeCli, foto = @fotoCli,
						email = @emailCli, senha = @senhaCli,
						status = @sts
	where idCliente = @idCli
end 
go

