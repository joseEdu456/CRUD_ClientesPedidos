
create view ped_info
as
select p.ped_numero Pedido,
       p.ped_data   Data,
       case ped_status
	      when 1 then 'Ativo'
		  when 2 then 'Pendente'
		  When 3 then 'Cancelado'		  
	   end Situação,
	   cli.pes_nome Cliente,
	   fun.pes_nome Funcionario,
	   est.pes_nome Estagiario
from pedidos p, pessoas cli, pessoas fun, pessoas est
where p.cli_codigo = cli.pes_codigo and
      p.fun_codigo = fun.pes_codigo and
	  p.est_codigo = est.pes_codigo

