create procedure cadPessoa
(
	@pessoa_nome varchar(50),
	@pessoa_cpf   varchar(15),
	@pessoa_email   varchar(50),
	@pessoa_telefone   varchar(15)
)
as
begin
	insert into Pessoa values	(@pessoa_nome,@pessoa_cpf, @pessoa_email, @pessoa_telefone)
end
go

