CREATE procedure cadcli
(
	@nome varchar(50), @cpf varchar(12),
	@renda decimal(10,2)
)
as
begin
	begin try
		begin tran
		insert into pessoas values 	(@nome, @cpf, 1)
		insert into clientes values	(@@identity, @renda, @renda*0.25) 
		commit
		return 0
	end try
	begin catch		
	    rollback
		raiserror ('Problema no cadastrar Cliente', 16, 1)
		return 1
	end catch
end
go

