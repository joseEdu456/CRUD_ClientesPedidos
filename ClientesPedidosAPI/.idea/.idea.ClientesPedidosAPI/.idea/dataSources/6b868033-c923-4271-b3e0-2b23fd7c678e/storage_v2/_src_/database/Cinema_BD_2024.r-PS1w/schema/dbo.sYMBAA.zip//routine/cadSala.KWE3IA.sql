create procedure cadSala
(
	@sala_status int
)
as
begin
	insert into Salas values (@sala_status)
end
go

