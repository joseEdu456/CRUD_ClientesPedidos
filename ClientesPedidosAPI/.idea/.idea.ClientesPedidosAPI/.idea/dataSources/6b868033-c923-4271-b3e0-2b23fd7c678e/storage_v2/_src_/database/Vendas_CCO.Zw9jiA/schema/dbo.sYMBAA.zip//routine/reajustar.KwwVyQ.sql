

create function reajustar
(
	@valor decimal(10,2),
	@taxa  decimal(10,2)
)
returns decimal(10,2)
as
begin
   return (@valor * (1 + @taxa/100))
end
go

