create procedure cadConsumacao
(
	@consumacao_valor decimal(10,2),
	@funcinario_id int
)
as
begin
	insert into Consumacao values (@consumacao_valor, @funcinario_id)
end
go

