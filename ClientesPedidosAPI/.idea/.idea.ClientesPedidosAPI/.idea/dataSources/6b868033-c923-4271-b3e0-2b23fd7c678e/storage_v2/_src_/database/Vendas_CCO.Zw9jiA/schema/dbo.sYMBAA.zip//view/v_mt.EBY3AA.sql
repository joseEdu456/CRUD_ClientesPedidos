create view v_mt
as
   select * from mytable
go

