create procedure cadComanda
(
	@comanda_data datetime,
	@valor_comanda decimal(10,2),
	@ingresso_nr int,
	@cliente_id int,
	@funcionario_id int,
	@forma_pagamento_id int
)
as
begin
	insert into Comanda values (@comanda_data, @valor_comanda, @ingresso_nr, @cliente_id, @funcionario_id, @forma_pagamento_id)
end
go

