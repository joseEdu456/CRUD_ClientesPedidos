create function buscarPedCli (@cliente int)
returns @ped table (nr int, data date, 
              total money, funcionario varchar(50))
as
begin    
	insert into @ped select ped_numero, ped_data, 
	                        ped_valor, f.pes_nome
	from pedidos p, pessoas f
	where p.fun_codigo = f.pes_codigo and
	      p.cli_codigo = @cliente	    
	return
end
go

