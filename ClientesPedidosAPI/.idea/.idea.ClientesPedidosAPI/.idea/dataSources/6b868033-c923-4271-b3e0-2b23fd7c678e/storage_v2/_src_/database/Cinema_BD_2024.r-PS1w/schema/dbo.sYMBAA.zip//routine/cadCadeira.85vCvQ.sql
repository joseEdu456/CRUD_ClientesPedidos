create procedure cadCadeira
(
	@cadeira_status int
)
as
begin
	insert into Cadeiras values	(@cadeira_status)
end
go

