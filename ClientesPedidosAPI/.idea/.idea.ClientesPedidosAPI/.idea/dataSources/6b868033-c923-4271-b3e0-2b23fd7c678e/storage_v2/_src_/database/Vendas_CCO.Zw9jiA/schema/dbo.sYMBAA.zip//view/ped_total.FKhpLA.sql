
create view ped_total
as
	select ped_numero Pedido, 
		   sum(itp_qtd * itp_valor) Valor_Item
	from itens_pedidos
	group by ped_numero
go

