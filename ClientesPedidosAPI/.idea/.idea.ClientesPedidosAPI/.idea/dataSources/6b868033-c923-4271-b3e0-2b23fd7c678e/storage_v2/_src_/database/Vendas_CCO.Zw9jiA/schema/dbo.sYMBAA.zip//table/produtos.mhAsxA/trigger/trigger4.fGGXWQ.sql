create trigger trigger4
on produtos
instead of insert
as
begin
   insert into prod_copy
   select i.prd_descricao,i.prd_qtd, i.prd_valor,
		  getdate()		  
   from inserted i
end
go

