
-------------------------------------------------------------
-- Procedure para cadastrar os Produtos na TABELA PRODUTOS 
-------------------------------------------------------------
create procedure sp_CadProduto
(
	@nomeProd	varchar(20),		@descProd	varchar(100),
	@qtdProd	int,				@precoProd	decimal(6,2),
	@imgProd	varchar(150),		@stsProd	int,
	@catIdProd	int
)
as
begin
	insert into Produtos (nome, descricao, qtdProd, valor, urlImg, status, categoriaId)
	values(@nomeProd, @descProd, @qtdProd, (@precoProd/100), @imgProd, @stsProd, @catIdProd)
end 
go

