
-------------------------------------------------------------
-- View para consultar todos os Clientes na TABELA CLIENTES
-------------------------------------------------------------
create view v_Cliente
as
	select C.idCliente, C.nomeCli, C.foto, C.email, C.senha, C.status
	from Clientes C
go

