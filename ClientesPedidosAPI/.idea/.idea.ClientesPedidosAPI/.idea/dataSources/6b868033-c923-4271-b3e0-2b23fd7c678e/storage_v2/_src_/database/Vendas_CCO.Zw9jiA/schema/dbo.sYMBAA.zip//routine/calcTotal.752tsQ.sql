
create function calcTotal(@nr int)
returns money
as
begin
	return
	 (
	   select sum(itp_qtd * itp_valor)
	   from itens_pedidos
	   where ped_numero = @nr
	)
end
go

