create procedure cadConsumacao_Bebida
(
	@bebida_id int,
	@consumacao_id int,
	@qtd int
)
as
begin
	insert into Consumacao_Bebida values (@bebida_id, @consumacao_id, @qtd)
end
go

