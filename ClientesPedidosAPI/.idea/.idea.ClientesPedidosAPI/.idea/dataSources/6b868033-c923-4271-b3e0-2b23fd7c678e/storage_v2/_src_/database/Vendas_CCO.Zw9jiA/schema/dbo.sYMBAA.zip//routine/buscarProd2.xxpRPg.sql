create function buscarProd2 ( @preco decimal(10,2) )
returns table
as
 return ( select prd_descricao Produto,
                 prd_qtd       Estoque,
		         prd_valor     Preco
          from produtos 
		  where prd_valor > @preco
		 )
go

