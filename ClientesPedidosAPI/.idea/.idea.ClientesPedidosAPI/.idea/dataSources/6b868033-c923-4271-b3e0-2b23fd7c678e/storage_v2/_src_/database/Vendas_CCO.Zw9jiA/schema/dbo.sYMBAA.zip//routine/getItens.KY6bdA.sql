create function getItens (@nr int)
returns table
as
return (
	select p.prd_descricao Produto,
		   ip.itp_qtd      Qtd,
		   ip.itp_valor    Preco_Unitario,
		   ip.itp_qtd * ip.itp_valor Valor
	from itens_pedidos ip, produtos p 
	where ped_numero = @nr and
		  ip.prd_codigo = p.prd_codigo
)
go

