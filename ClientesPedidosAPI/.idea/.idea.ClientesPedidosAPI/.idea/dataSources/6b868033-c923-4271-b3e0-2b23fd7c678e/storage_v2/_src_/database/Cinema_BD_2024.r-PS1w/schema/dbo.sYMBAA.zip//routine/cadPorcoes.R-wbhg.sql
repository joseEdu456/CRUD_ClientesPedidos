create procedure cadPorcoes
(
	@porcoes_valor decimal(10,2),
	@porcoes_desc varchar(40)
)
as
begin
	insert into Porcoes values (@porcoes_valor, @porcoes_desc)
end
go

